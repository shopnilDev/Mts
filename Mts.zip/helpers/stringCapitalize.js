// capitalize.js
function stringCapitalize(string) {
  if (!string) return "";
  return string.toUpperCase();
}

export default stringCapitalize;
