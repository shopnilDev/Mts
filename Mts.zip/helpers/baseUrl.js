export const BASE_URL = "http://mathmozocms.test"; // Replace with your actual base URL
// export const BASE_URL = "http://mathmozocms.test"; // Replace with your actual base URL

//export const BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || "http://mathmozocms.test/api/v1";
// process.env.NEXT_PUBLIC_API_BASE_URL || "https://admin.mtsbd.net/api/v1";
