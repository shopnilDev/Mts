import React from 'react'

const Top_header = () => {
  return (
    <>
                <header className='z-10'>
                <h1 className='bg-topHeaderColor py-1 text-center text-white text-sm'> Inteltec Emirates Group</h1>
            </header>
    </>
  )
}

export default Top_header
